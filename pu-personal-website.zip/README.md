# Personal website

## Requirements
- HTML, CSS, Javascript / jQuery.
- PHP programming language
- Local dev environment - Wamp64, or 
  simple php & command: `php -S localhost:8000`

## Example site
- 
